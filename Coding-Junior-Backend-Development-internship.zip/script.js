function updateSectionProgress(section, progress) {
  const progressBar = document.getElementById(`${section}-progress-bar`);
  progressBar.style.width = `${progress}% - ${section}`;
}
